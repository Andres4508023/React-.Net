using System;

namespace Aplicacion.Cursos
{
    public class CursoInstructorDto
    {
        public Guid CursoId {get;set;}

        public Guid InstructorId {get;set;}
    }
}