namespace Persistencia.DapperConexion
{
    public class ConexionConfiguracion
    {
        public string DefaultConnection {get;set;}
    }
}